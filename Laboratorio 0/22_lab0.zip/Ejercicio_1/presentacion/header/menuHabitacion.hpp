#ifndef HABITACION_MENU_H
#define HABITACION_MENU_H

#include "../../persistencia/header/Sistema.hpp"
#include <stdlib.h>
#include <iostream>

using namespace std;

void agregarHabitacion(Sistema* systemData);
void obtenerHabitaciones(Sistema* systemData);

#endif
