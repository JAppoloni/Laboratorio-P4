#include "../include/TipoDePlataforma.hpp"

TipoDePlataforma::TipoDePlataforma(std::string n, std::string d) : Categoria(n, d) {}

