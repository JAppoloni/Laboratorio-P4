#ifndef _CONSTANTES_HH_
#define _CONSTANTES_HH_

#define MAX_HABITACIONES 100 // MAX_HABITACIONES = ? Val
#define MAX_RESERVAS 100     // MAX_RESERVAS = ? Val
#define MAX_HUESPEDES 100    // MAX_HUESPEDES = ? Val  También está en DTReservaGrupal
#endif
