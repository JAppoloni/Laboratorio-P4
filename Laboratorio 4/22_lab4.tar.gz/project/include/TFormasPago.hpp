#ifndef TFORMASDEPAGO_HPP
#define TFORMASDEPAGO_HPP

enum TFormasPago {tarjeta, PayPal} ;

#endif