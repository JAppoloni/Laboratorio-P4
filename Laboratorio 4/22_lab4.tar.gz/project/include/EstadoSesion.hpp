#ifndef ESTADO_SESION_HPP
#define ESTADO_SESION_HPP

enum EstadoSesion { sin_usuario, desarrollador, jugador };

#endif