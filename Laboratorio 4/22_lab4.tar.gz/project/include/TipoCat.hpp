#ifndef TIPOCAT_HPP
#define TIPOCAT_HPP

enum TipoCat {plataforma, genero, otro} ;

#endif