#ifndef TIPOSSUSCRIPCION_HPP
#define TIPOSSUSCRIPCION_HPP

enum TiposSuscripcion {un_mes, tres_meses, un_anio, vitalicio} ; 
#endif