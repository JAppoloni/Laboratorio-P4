#include "../include/Otros.hpp"

Otros::Otros(std::string n, std::string d) : Categoria(n, d) {}