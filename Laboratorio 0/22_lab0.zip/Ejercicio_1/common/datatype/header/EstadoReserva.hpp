#ifndef _ESTADORESERVA_HH_
#define _ESTADORESERVA_HH_

    enum EstadoReserva { Abierta, Cerrada, Cancelada} ;

#endif
