#include "../include/Genero.hpp"

Genero::Genero(std::string n, std:: string d) : Categoria(n, d) {}
