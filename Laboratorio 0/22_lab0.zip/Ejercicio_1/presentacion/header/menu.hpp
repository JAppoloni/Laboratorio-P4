#ifndef MAIN_MENU_H
#define MAIN_MENU_H

#include "../../persistencia/header/Sistema.hpp"
#include <stdlib.h>
#include <iostream>

using namespace std;

void mainMenu(Sistema* systemData);

#endif
