#ifndef RESERVAS_MENU_H
#define RESERVAS_MENU_H

#include "../../persistencia/header/Sistema.hpp"
#include <stdlib.h>
#include <iostream>

using namespace std;

void registrarReserva(Sistema* systemData);
void obtenerReservas(Sistema* systemData);

#endif
